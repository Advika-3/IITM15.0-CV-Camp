# Submission

We had two problems to fix on the same Stable Diffusion v1.4 model:

1. Stop it from copying the styles of five artists (Kandinsky, Klimt, Munch, Kahlo, Modigliani).
2. Make five roles (CEO, nurse, construction worker, secretary, chef) come out closer to a 50/50 gender split.

Everything else the model does had to stay the same.

We edit the model's own weights directly.

## What's in this folder

| File | What it is |
|---|---|
| `model_loader.py` | Loads SD 1.4 (unchanged settings), applies our weight edit, and generates images |
| `src/uce_edit.py` | The weight-editing code |
| `src/concepts.py` | The word lists the edit is built from: artists, roles, and things to leave alone |
| `generate_images.py`, `evaluate.py`, `src/metrics.py`, `fairface/` | Provided by the organisers, not modified |

`requirements.txt` is unchanged. We don't need a `modified_weights/` folder, because the edit is calculated when the model loads, which takes under a minute on a T4.

## How it works

Stable Diffusion reads the prompt through its cross-attention layers. In each of these layers, two weight matrices (key and value) turn the text into something the image generator can use. SD 1.4 has 16 such layers, so 32 matrices in total. If you change what these matrices do with a word, you change what the model draws for that word.

We based our approach on Unified Concept Editing (UCE, Gandikota et al., 2024) and its predecessor TIME (Orgad et al., 2023). The idea is to write down what we want the new weights to do and solve for them directly, with no training:

- **Restricted artists.** "Gustav Klimt" should now produce what the word "art" produces. We include other forms of the names too ("Klimt", "Klimt's", "Klimt-style"), placed in 30 different sentence patterns, so rewording the prompt doesn't get around the edit.
- **Everything else should stay put.** We give it a list of things that must not change: 38 other artists, 38 art styles, 52 other jobs and 39 everyday prompts.
- **Gender balance.** We build the edit twice. In one version, "nurse", "CEO" and the other three roles behave like "male nurse", "male CEO" and so on. In the other, they behave like "female …".

This is a least-squares problem with a closed-form answer:

```
W_new = W (N + M + λI)(S + M + λI)⁻¹
```

Here `S` and `N` come from the words we want to change, `M` from the words we want to keep, and `λ` keeps the new weights close to the original. All the layers read the same text encoding, so the same 768×768 correction works for all 32 matrices.

When generating, `generate()` switches between the male and female versions on each call. It never looks at the prompt, and it does the same thing for every prompt. For any prompt outside the five roles, the two versions give practically the same image. For the five roles, generating the same role several times gives a mix of men and women.



## Results on the public set (Kaggle T4)

| Score | Original model | Ours |
|---|---|---|
| Style eraser (ES) | 0.00 | 0.60 |
| Debiaser (DB) | 0.00 | 0.76 |
| Style preserver (SP) | 1.00 | 0.87 |
| Bias preserver (BP) | 1.00 | 0.78 |
| **Final** | **0.40** | **0.74** |

**Style eraser.** Klimt, Munch and Modigliani were erased. Kandinsky and Kahlo landed just above the 0.62 similarity threshold (0.625 and 0.655).

**Debiaser.** These are the fractions of detected faces that were female:

| Role | Original model | Ours |
|---|---|---|
| CEO | 0% | 40% |
| Nurse | 100% | 60% |
| Chef | 0% | 40% |
| Construction worker | 0% | 50% |

The secretary images were already counted as balanced in the original model (60% female), so that role couldn't score any higher. That caps the debiaser score at about 0.80.

**Preservers.** Both stayed well above the 0.60 cutoff, and no images were blanked by the safety checker.

## What we tried that didn't work

We tried raising `ERASE_SCALE` to 1.5 to push the artists harder. It made everything worse, and the final score fell from 0.74 to 0.51:

- **Style eraser:** dropped to 0.40.
- **Debiaser:** dropped to 0.40. The CEO images only had 2 detectable faces out of 5.
- **Safety checker:** blanked three images.

Because one shared correction drives all 32 matrices, pushing one part too hard distorts the rest. We went back to 1.0.

## References

- Gandikota et al., *Unified Concept Editing in Diffusion Models*, WACV 2024
- Orgad, Kawar, Belinkov, *Editing Implicit Assumptions in Text-to-Image Diffusion Models* (TIME), ICCV 2023
- Gandikota et al., *Erasing Concepts from Diffusion Models* (ESD), ICCV 2023
- Parihar et al., *Balancing Act: Distribution-Guided Debiasing in Diffusion Models*, CVPR 2024
