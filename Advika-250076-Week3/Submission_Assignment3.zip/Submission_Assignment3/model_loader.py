import os
import sys
import traceback

import torch
from diffusers import StableDiffusionPipeline
from PIL import Image

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

MODEL_ID = "CompVis/stable-diffusion-v1-4"
REVISION = "133a221"  
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32

ERASE_SCALE = 1.0    
DEBIAS_SCALE = 1.0     
PRESERVE_WEIGHT = 1.0
LAM_REL = 5e-2   

_BANK_ORDER = ("female", "male")
_STATE = {"calls": 0}


def _apply_modification(pipe):
    from uce_edit import build_transforms, make_weight_banks, load_bank
    transforms = build_transforms(pipe,
                                  erase_scale=ERASE_SCALE,
                                  debias_scale=DEBIAS_SCALE,
                                  preserve_weight=PRESERVE_WEIGHT,
                                  lam_rel=LAM_REL)
    banks = make_weight_banks(pipe, transforms)
    del transforms
    pipe._uce_banks = banks
    pipe._uce_load_bank = load_bank
    load_bank(pipe, banks, _BANK_ORDER[0])
    if DEVICE == "cuda":
        torch.cuda.empty_cache()
    print("[model_loader] UCE cross-attention edit applied "
          f"({len(banks[_BANK_ORDER[0]])} projections, banks={list(banks)})")


def load_model():
    """Return a ready-to-use pipeline with the edited cross-attention weights."""
    pipe = StableDiffusionPipeline.from_pretrained(
        MODEL_ID,
        revision=REVISION,
        torch_dtype=DTYPE,
    ).to(DEVICE)
    pipe.set_progress_bar_config(disable=False)

  
    try:
        _apply_modification(pipe)
    except Exception: 
        traceback.print_exc()
        print("[model_loader] WARNING: edit failed, falling back to base weights.")
        pipe._uce_banks = None

    return pipe


@torch.no_grad()
def generate(pipe, prompt: str, seed: int) -> Image.Image:
    """Generate one image. Do not change the signature."""
    banks = getattr(pipe, "_uce_banks", None)
    if banks:
        bank = _BANK_ORDER[_STATE["calls"] % len(_BANK_ORDER)]
        pipe._uce_load_bank(pipe, banks, bank)
    _STATE["calls"] += 1

    generator = torch.Generator(device=DEVICE).manual_seed(seed)
    output = pipe(prompt, num_inference_steps=50, generator=generator)
    image = output.images[0]
    flagged = getattr(output, "nsfw_content_detected", None)
    if flagged and flagged[0]:
        print(f"[NSFW FILTER] blocked prompt={prompt!r} seed={seed}")
    return image
