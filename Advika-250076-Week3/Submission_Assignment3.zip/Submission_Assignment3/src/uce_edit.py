
import torch

from concepts import (ERASE_ARTISTS, ERASE_ANCHOR, ARTIST_TEMPLATES,
                      DEBIAS_ROLES, GENDER_WORDS, ROLE_TEMPLATES,
                      PRESERVE_ARTISTS, PRESERVE_STYLES, PRESERVE_ROLES,
                      PRESERVE_TEMPLATES, PRESERVE_GENERIC)

ART_PRESERVE_TEMPLATES = [t for t in PRESERVE_TEMPLATES if "photo" not in t]
ROLE_PRESERVE_TEMPLATES = [t for t in PRESERVE_TEMPLATES if "photo" in t or t == "{}"]

def _maxlen(tokenizer):
    L = getattr(tokenizer, "model_max_length", 77)
    return L if isinstance(L, int) and 0 < L <= 512 else 77


def _n_tokens(tokenizer, text):
    return len(tokenizer(text, add_special_tokens=False).input_ids)


def _span(tokenizer, template, concept):
    prompt = template.format(concept)
    prefix = template.split("{}")[0].strip()
    start = 1 + (_n_tokens(tokenizer, prefix) if prefix else 0)   # +1 for BOS
    n_c = _n_tokens(tokenizer, concept)
    L = _maxlen(tokenizer)
    ids = tokenizer(prompt, padding="max_length", truncation=True,
                    max_length=L).input_ids
    concept_ids = tokenizer(concept, add_special_tokens=False).input_ids
    end = start + n_c
    if end >= L or ids[start:end] != concept_ids:
        return None
    return prompt, start, end

@torch.no_grad()
def _encode(pipe, prompts, batch_size=64):
    tok, enc = pipe.tokenizer, pipe.text_encoder
    device = enc.device
    out = []
    for i in range(0, len(prompts), batch_size):
        ids = tok(prompts[i:i + batch_size], padding="max_length", truncation=True,
                  max_length=_maxlen(tok), return_tensors="pt").input_ids
        out.append(enc(ids.to(device))[0].float().cpu())
    return torch.cat(out, 0) if out else torch.zeros(0, _maxlen(tok), enc.config.hidden_size)


_CHUNK = 128


class _Stats:
    def __init__(self, d):
        self.S = torch.zeros(d, d, dtype=torch.float64)   
        self.N = torch.zeros(d, d, dtype=torch.float64)   
        self.count = 0

    def add(self, src, tgt, weight=1.0):
        src, tgt = src.double(), tgt.double()
        self.S += weight * src.T @ src
        self.N += weight * tgt.T @ src
        self.count += src.shape[0]


def _pairs_stats(pipe, pairs, d):
    tok = pipe.tokenizer
    L = _maxlen(tok)
    items = []
    for tpl, src, tgt in pairs:
        a, b = _span(tok, tpl, src), _span(tok, tpl, tgt)
        if a is None or b is None:
            continue
        items.append((a, b))
    stats = _Stats(d)
    for c0 in range(0, len(items), _CHUNK):
        chunk = items[c0:c0 + _CHUNK]
        emb_src = _encode(pipe, [a[0] for a, _ in chunk])
        emb_tgt = _encode(pipe, [b[0] for _, b in chunk])
        rows_s, rows_t = [], []
        for k, ((_, s0, s1), (_, t0, t1)) in enumerate(chunk):
            src_idx = list(range(s0, s1))
            tgt_idx = [t1 - 1] * (s1 - s0)
            j = 1
            while s1 - 1 + j < L and t1 - 1 + j < L:
                src_idx.append(s1 - 1 + j)
                tgt_idx.append(t1 - 1 + j)
                j += 1
            rows_s.append(emb_src[k, src_idx])
            rows_t.append(emb_tgt[k, tgt_idx])
        stats.add(torch.cat(rows_s), torch.cat(rows_t))
    return stats


def _preserve_stats(pipe, d):
    tok = pipe.tokenizer
    L = _maxlen(tok)
    prompts, starts = [], []
    for c in PRESERVE_ARTISTS + PRESERVE_STYLES:
        for tpl in ART_PRESERVE_TEMPLATES:
            sp = _span(tok, tpl, c)
            if sp:
                prompts.append(sp[0]); starts.append(sp[1])
    for c in PRESERVE_ROLES:
        for tpl in ROLE_PRESERVE_TEMPLATES:
            sp = _span(tok, tpl, c)
            if sp:
                prompts.append(sp[0]); starts.append(sp[1])
    for p in PRESERVE_GENERIC:
        prompts.append(p); starts.append(1)
    M = torch.zeros(d, d, dtype=torch.float64)
    n = 0
    for c0 in range(0, len(prompts), _CHUNK):
        emb = _encode(pipe, prompts[c0:c0 + _CHUNK])
        c = torch.cat([emb[k, s0:L] for k, s0 in enumerate(starts[c0:c0 + _CHUNK])]).double()
        M += c.T @ c
        n += c.shape[0]
    return M, n


def build_transforms(pipe, erase_scale=1.0, debias_scale=1.0,
                     erase_weight=1.0, debias_weight=1.0, preserve_weight=1.0,
                     lam_rel=5e-2):
    """Return {"male": T_m, "female": T_f}, two 768x768 float64 matrices.

    Both share the artist erasure and the preserve set; they differ only in
    which gender presentation the five corrected roles are steered toward."""
    d = pipe.text_encoder.config.hidden_size

    erase_pairs = [(tpl, form, ERASE_ANCHOR)
                   for forms in ERASE_ARTISTS.values()
                   for form in forms for tpl in ARTIST_TEMPLATES]
    erase = _pairs_stats(pipe, erase_pairs, d)
    M, n_pres = _preserve_stats(pipe, d)
    print(f"[uce] erase vectors={erase.count}  preserve vectors={n_pres}")

    transforms = {}
    for bank, word in GENDER_WORDS.items():
        role_pairs = [(tpl, form, f"{word} {form}")
                      for forms in DEBIAS_ROLES.values()
                      for form in forms for tpl in ROLE_TEMPLATES]
        deb = _pairs_stats(pipe, role_pairs, d)
        print(f"[uce] bank={bank} debias vectors={deb.count}")

        # target scaling: c* <- c + s (c* - c)  =>  N <- S + s (N - S)
        N_e = erase.S + erase_scale * (erase.N - erase.S)
        N_d = deb.S + debias_scale * (deb.N - deb.S)

        S_tot = erase_weight * erase.S + debias_weight * deb.S + preserve_weight * M
        N_tot = erase_weight * N_e + debias_weight * N_d + preserve_weight * M
        lam = lam_rel * torch.trace(S_tot) / d
        I = torch.eye(d, dtype=torch.float64)
        # T = (N + lam I)(S + lam I)^-1  computed as solve on the transpose
        A = S_tot + lam * I
        B = N_tot + lam * I
        T = torch.linalg.solve(A.T, B.T).T
        transforms[bank] = T
    return transforms


def cross_attn_projections(unet):
    """All cross-attention key/value Linear layers (attn2.to_k / attn2.to_v)."""
    mods = []
    for name, mod in unet.named_modules():
        if name.endswith("attn2.to_k") or name.endswith("attn2.to_v"):
            mods.append((name, mod))
    return mods


@torch.no_grad()
def make_weight_banks(pipe, transforms):
    """Pre-compute the edited K/V weights for every bank (stored in model dtype)."""
    banks = {b: [] for b in transforms}
    for name, mod in cross_attn_projections(pipe.unet):
        W = mod.weight.data.double().cpu()
        for b, T in transforms.items():
            banks[b].append((W @ T).to(dtype=mod.weight.dtype,
                                       device=mod.weight.device))
    return banks


@torch.no_grad()
def load_bank(pipe, banks, bank):
    for (name, mod), W in zip(cross_attn_projections(pipe.unet), banks[bank]):
        mod.weight.data.copy_(W)
